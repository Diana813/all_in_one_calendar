package com.dianaszczepankowska.AllInOneCalendar.android.events.expandedDayView;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.dianaszczepankowska.AllInOneCalendar.android.CalendarProviderMethods;
import com.dianaszczepankowska.AllInOneCalendar.android.R;
import com.dianaszczepankowska.AllInOneCalendar.android.calendar.CalendarUtils;
import com.dianaszczepankowska.AllInOneCalendar.android.events.eventsUtils.EventsListAdapter;
import com.dianaszczepankowska.AllInOneCalendar.android.events.eventsUtils.EventsViewModel;
import com.dianaszczepankowska.AllInOneCalendar.android.events.eventsUtils.UtilsEvents;
import com.dianaszczepankowska.AllInOneCalendar.android.events.frequentActivities.FrequentActivitiesViewModel;
import com.dianaszczepankowska.AllInOneCalendar.android.gestures.GestureInteractionsRecyclerView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import static com.dianaszczepankowska.AllInOneCalendar.android.events.eventsUtils.UtilsEvents.addNotification;

public class ToDoList extends ExpandedDayEvents {


    private EventsListAdapter toDoListAdapter;
    private FrequentActivitiesDrawerListAdapter frequentActivitiesDrawerListAdapter;
    private int layout;
    private RecyclerView freqActDrawList;
    private RecyclerView toDoListRecyclerView;
    private ImageButton confirm;
    private EditText editText;
    private TextView eventsLabel;


    public void setContent(int layout) {
        this.layout = layout;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        toDoListAdapter = new EventsListAdapter(context);
        frequentActivitiesDrawerListAdapter = new FrequentActivitiesDrawerListAdapter(context);
    }


    @Override
    public void onPause() {
        super.onPause();
        toDoListAdapter.setIndexInDB();
        toDoListAdapter.deleteFromDatabase(null);
        CalendarUtils.saveEventsNumberToPickedDate(pickedDay, context);

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(layout, container, false);

        findViews(rootView);
        eventsLabel.setVisibility(View.GONE);
        editText.setTextColor(Color.BLACK);
        setAdapters();
        setHasOptionsMenu(true);
        pickedDay = findWhatDateItIs();

        CalendarProviderMethods.getDataFromEventTable(context);
       /* EventsDao dao = CalendarDatabase.getDatabase(context).eventsDao();
        dao.deleteByEventKind(1);*/
        initData();
        addFreqActivList();
        displayCyclicalEvents();
        UtilsEvents.setConfirmButtonEvents(getContext(), confirm, toDoListAdapter, editText, pickedDay, null, "0", "", 1);
        return rootView;
    }

    private void findViews(View rootView) {
        freqActDrawList = rootView.findViewById(R.id.widgetGridView);
        toDoListRecyclerView = rootView.findViewById(R.id.list);
        mDrawer = rootView.findViewById(R.id.activity_expanded_day_view);
        confirm = rootView.findViewById(R.id.confirm_button);
        editText = rootView.findViewById(R.id.editText);
        eventsLabel = rootView.findViewById(R.id.eventsLabel);
        mDrawer = rootView.findViewById(R.id.activity_expanded_day_view);
        navigationView = rootView.findViewById(R.id.nvView);
    }

    private void setAdapters() {
        freqActDrawList.setAdapter(frequentActivitiesDrawerListAdapter);
        freqActDrawList.setLayoutManager(new LinearLayoutManager(context));
        toDoListRecyclerView.setAdapter(toDoListAdapter);
        toDoListRecyclerView.setLayoutManager(new LinearLayoutManager(context));
        ItemTouchHelper itemTouchHelper = new
                ItemTouchHelper(new GestureInteractionsRecyclerView(toDoListAdapter));
        itemTouchHelper.attachToRecyclerView(toDoListRecyclerView);
        mDrawer.setScrimColor(Color.TRANSPARENT);

    }

    void saveEvent(String newEvent, String pickedDate) {
        UtilsEvents.saveDataEvents(null, pickedDate, newEvent, "-1", "", 1, UtilsEvents.createEventId(pickedDate));
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.action_delete_all_entries) {
            showDeleteConfirmationDialog(1);
            initData();
            return true;
        } else if (item.getItemId() == R.id.action_open_drawer) {
            mDrawer.openDrawer(navigationView);
            toDoListAdapter.deleteFromDatabase(null);
            return true;
        } else if (item.getItemId() == R.id.action_add_notification) {
            addNotification(getView(), context);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void initData() {

        EventsViewModel eventsViewModel = new ViewModelProvider(this).get(EventsViewModel.class);
        eventsViewModel.getEventsList().observe(getViewLifecycleOwner(), events -> {
            assert events != null;
            toDoListAdapter.setEventsList(events);
            eventsListSize = events.size();

        });
    }

    private void addFreqActivList() {

        FrequentActivitiesViewModel frequentActivitiesViewModel = new ViewModelProvider(this).get(FrequentActivitiesViewModel.class);
        frequentActivitiesViewModel.getEventsList().observe(getViewLifecycleOwner(), events -> {
            assert events != null;
            frequentActivitiesDrawerListAdapter.setEventsList(events);
        });
    }


}

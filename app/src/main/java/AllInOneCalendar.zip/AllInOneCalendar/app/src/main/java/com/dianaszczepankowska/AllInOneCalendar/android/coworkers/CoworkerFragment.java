package com.dianaszczepankowska.AllInOneCalendar.android.coworkers;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.dianaszczepankowska.AllInOneCalendar.android.R;

import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class CoworkerFragment extends Fragment {

    private ColleaguesListAdapter colleaguesListAdapter;
    private RecyclerView friendsRecyclerView;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        colleaguesListAdapter = new ColleaguesListAdapter(context);
    }


    public CoworkerFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_coworker, container, false);
        Objects.requireNonNull(getActivity()).setTitle(getString(R.string.Coworkers));

        colleaguesListAdapter.setUsersList();
        friendsRecyclerView = rootView.findViewById(R.id.friendsList);
        friendsRecyclerView.setAdapter(colleaguesListAdapter);
        friendsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        return rootView;
    }

}

package com.dianaszczepankowska.AllInOneCalendar.android.utils;

public interface CopyPasteEditTextListener {
    void onUpdate();
}

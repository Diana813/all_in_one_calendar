package com.dianaszczepankowska.AllInOneCalendar.android.coworkers;

public class CoworkersUtils {

    public static void showFriendsList(){

    }

    public static void shareDataWithFriend(){

    }
}

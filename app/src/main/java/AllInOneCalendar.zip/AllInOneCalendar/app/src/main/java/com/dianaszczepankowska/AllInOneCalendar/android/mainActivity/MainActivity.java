package com.dianaszczepankowska.AllInOneCalendar.android.mainActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.StatusBarManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.dianaszczepankowska.AllInOneCalendar.android.R;
import com.dianaszczepankowska.AllInOneCalendar.android.calendar.CalendarFragment;
import com.dianaszczepankowska.AllInOneCalendar.android.coworkers.CoworkerFragment;
import com.dianaszczepankowska.AllInOneCalendar.android.events.cyclicalEvents.CyclicalEvents;
import com.dianaszczepankowska.AllInOneCalendar.android.events.frequentActivities.FrequentActivities;
import com.dianaszczepankowska.AllInOneCalendar.android.forGirls.ForGirlsFragment;
import com.dianaszczepankowska.AllInOneCalendar.android.personalGrowth.BackgroundActivity;
import com.dianaszczepankowska.AllInOneCalendar.android.shifts.ShiftsFragment;
import com.dianaszczepankowska.AllInOneCalendar.android.widget.WidgetUtils;
import com.google.android.material.bottomnavigation.BottomNavigationMenu;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.wear.widget.drawer.WearableActionDrawerView;
import androidx.wear.widget.drawer.WearableDrawerLayout;
import androidx.wear.widget.drawer.WearableDrawerView;
import androidx.wear.widget.drawer.WearableNavigationDrawerView;


public class MainActivity extends AppCompatActivity {

    public CoordinatorLayout mDrawer;
    private FrameLayout bottomMenu;
    private ActionBarDrawerToggle drawerToggle;
    private ExpandableListView expandableListView;
    private CustomExpandableListAdapter expandableListAdapter;
    private static double screenHeight;
    private BottomSheetBehavior sheetBehavior;
    private LinearLayout bottom_sheet;

    @Override
    public void onPause() {
        super.onPause();
        WidgetUtils.updateWidget(this);
        WidgetUtils.updateWidgetAtMidnight(this);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
        tx.replace(R.id.flContent, new CalendarFragment());
        tx.commit();

        //no background for status bar
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

        Toolbar toolbar = findViewById(R.id.toolbar1);
        setSupportActionBar(toolbar);


        expandableListView = findViewById(R.id.expandableListView);
        mDrawer = findViewById(R.id.coordinator);
        setBottomNavigation();
        addListData();

        bottom_sheet = findViewById(R.id.bottom_sheet_menu);
        sheetBehavior = BottomSheetBehavior.from(bottom_sheet);
        //drawerToggle = setupDrawerToggle();
        // mDrawer.addDrawerListener(drawerToggle);
        // drawerToggle.syncState();
        showMyAppOnTheShareListOfApps();
        // Bottom action drawer
      /*  wearableActionDrawer = (WearableActionDrawerView) findViewById(R.id.bottom_action_drawer);
        // Peeks action drawer on the bottom.

        wearableActionDrawer.setOnMenuItemClickListener(this::onOptionsItemSelected);*/

       /* BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(wearableActionDrawer);
        if (bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_COLLAPSED && wearableActionDrawer.getController() != null) {
            wearableActionDrawer.getController().closeDrawer();
        }
*/
        setUsableScreenDimensions();

    }


    private void showMyAppOnTheShareListOfApps() {

        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        if ("android.intent.action.SEND".equals(action) && "image/jpeg".equals(type)) {
            Uri receivedUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);

            if (receivedUri != null) {
                Fragment backgroundActivity = new BackgroundActivity();
                Bundle args = new Bundle();
                args.putParcelable("image", receivedUri);
                backgroundActivity.setArguments(args);
                FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
                tx.replace(R.id.flContent, backgroundActivity);
                tx.commit();
            }


        } else if ("android.intent.action.SEND".equals(action) && "text/plain".equals(type)) {

            Fragment backgroundActivity = new BackgroundActivity();
            Bundle args = new Bundle();
            args.putString("message", getString(R.string.imageMessage));
            backgroundActivity.setArguments(args);
            FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
            tx.replace(R.id.flContent, backgroundActivity);
            tx.commit();
        }
    }


   /* private ActionBarDrawerToggle setupDrawerToggle() {
        return new ActionBarDrawerToggle(this, mDrawer, toolbar, R.string.drawer_open, R.string.drawer_close);

    }*/

   /* @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (drawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        if (item.getItemId() == android.R.id.home) {

            return true;
        }
        return super.onOptionsItemSelected(item);

    }*/

   /* @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        drawerToggle.onConfigurationChanged(newConfig);
    }*/
/*
    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        drawerToggle.syncState();
    }*/

    @Override
    public void onBackPressed() {
        WearableDrawerLayout drawer = findViewById(R.id.activity_expanded_day_view);
        if (drawer.isShown()) {

        } else {
            super.onBackPressed();
        }
    }


    public LinkedHashMap<String, List<String>> getData() {

        LinkedHashMap<String, List<String>> expandableListDetail = new LinkedHashMap<>();

        List<String> calendar = new ArrayList<>();

        List<String> forGirls = new ArrayList<>();

        List<String> shifts = new ArrayList<>();

        List<String> coworkers = new ArrayList<>();

        List<String> personalGrowth = new ArrayList<>();

        List<String> events = new ArrayList<>();
        events.add(getString(R.string.CyclicalEvents));
        events.add(getString(R.string.FrequentActivities));

        expandableListDetail.put(getString(R.string.Calendar), calendar);
        expandableListDetail.put(getString(R.string.OneTimeEvents), events);
        expandableListDetail.put(getString(R.string.ForGirls), forGirls);
        expandableListDetail.put(getString(R.string.Shifts), shifts);
        expandableListDetail.put(getString(R.string.Coworkers), coworkers);
        expandableListDetail.put(getString(R.string.PersonalGrowth), personalGrowth);


        return expandableListDetail;
    }

    public static List<Integer> getIconData() {

        List<Integer> iconList = new ArrayList<>();

        iconList.add(R.drawable.baseline_date_range_black_48);
        iconList.add(R.drawable.baseline_today_black_48);
        iconList.add(R.drawable.baseline_filter_vintage_black_48);
        iconList.add(R.drawable.baseline_business_center_black_48);
        iconList.add(R.drawable.baseline_perm_contact_calendar_black_48);
        iconList.add(R.drawable.baseline_sentiment_satisfied_alt_black_48);

        return iconList;
    }


    private void addListData() {

        LinkedHashMap<String, List<String>> expandableListDetail = getData();
        List<String> expandableListTitle = new ArrayList<>(expandableListDetail.keySet());
        expandableListAdapter = new CustomExpandableListAdapter(this, expandableListTitle, expandableListDetail, getIconData());
        expandableListView.setAdapter(expandableListAdapter);

        expandableListView.setOnGroupClickListener(this::onGroupClick);


        expandableListView.setOnChildClickListener(this::onChildClick);
    }

    private void setUsableScreenDimensions() {

        DisplayMetrics dm = getResources().getDisplayMetrics();
        float screen_w = dm.widthPixels;
        float screen_h = dm.heightPixels;

        int resId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resId > 0) {
            screen_h -= getResources().getDimensionPixelSize(resId);
        }
        TypedValue typedValue = new TypedValue();
        if (getTheme().resolveAttribute(android.R.attr.actionBarSize, typedValue, true)) {
            screen_h -= getResources().getDimensionPixelSize(typedValue.resourceId);
        }
        screenHeight = screen_h;
    }

    public static double getScreenHeight() {
        return screenHeight;
    }

    public void setScreenHeight(double screenHeight) {
        MainActivity.screenHeight = screenHeight;
    }


    private boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
        Fragment fragment = null;
        Class fragmentClass = null;

        if (expandableListAdapter.getChildrenCount(groupPosition) > 0) {
            return false;
        }

        if (id == 0) {
            fragmentClass = CalendarFragment.class;

        }

        if (id == 2) {
            fragmentClass = ForGirlsFragment.class;
        }

        if (id == 3) {
            fragmentClass = ShiftsFragment.class;
        }
        if (id == 4) {
            fragmentClass = CoworkerFragment.class;
        }
        if (id == 5) {
            fragmentClass = BackgroundActivity.class;

        }

        try {
            assert fragmentClass != null;
            fragment = (Fragment) fragmentClass.newInstance();


        } catch (Exception e) {
            e.printStackTrace();
        }


        FragmentManager fragmentManager = getSupportFragmentManager();
        assert fragment != null;
        fragmentManager.beginTransaction().replace(R.id.flContent, fragment).addToBackStack(null).commit();

        return true;
    }

    private boolean onChildClick(ExpandableListView parent, View v, int groupPosition,
                                 int childPosition, long id) {
        Fragment fragment = null;

        Class fragmentClass;
        if (id == 1) {
            fragmentClass = FrequentActivities.class;
        } else if (id == 0) {
            fragmentClass = CyclicalEvents.class;
        } else {
            fragmentClass = CalendarFragment.class;
        }

        try {
            fragment = (Fragment) fragmentClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }

        FragmentManager fragmentManager = getSupportFragmentManager();
        assert fragment != null;
        fragmentManager.beginTransaction().replace(R.id.flContent, fragment).addToBackStack("tag").commit();


        return true;
    }

    private void setBottomNavigation() {
        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            Fragment fragment = null;
            Class fragmentClass = null;
            switch (item.getItemId()) {
                case R.id.home:
                    fragmentClass = CalendarFragment.class;
                    openClass(fragment, fragmentClass);
                    break;
                case R.id.events:
                    fragmentClass = CyclicalEvents.class;
                    openClass(fragment, fragmentClass);
                    break;
                case R.id.adjust:
                    fragmentClass = CalendarFragment.class;
                    openClass(fragment, fragmentClass);
                    break;
                case R.id.menu:
                    if (sheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED) {
                        sheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                    } else {
                        sheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                    }
                    break;
            }

            return true;
        });
    }

    private void openClass(Fragment fragment, Class fragmentClass) {

        try {
            assert fragmentClass != null;
            fragment = (Fragment) fragmentClass.newInstance();


        } catch (Exception e) {
            e.printStackTrace();

        }


        FragmentManager fragmentManager = getSupportFragmentManager();
        assert fragment != null;
        fragmentManager.beginTransaction().replace(R.id.flContent, fragment).addToBackStack(null).commit();

    }
}
